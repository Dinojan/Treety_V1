const mongoose = require('mongoose');
var checkout       = require('./models/checkout');

module.exports = function(app, passport) {
app.get('/', function(req, res) {
res.render('index.ejs',{user:req.user});//home page
});

app.get('/checkout', function(req, res) {
    res.render('checkout.ejs'); // checkout.ejs
});
app.get('/product-page', function(req, res) {
    res.render('product-page.ejs'); // product-page.ejs
});
app.get('/shop', function(req, res) {
    res.render('shop.ejs'); //  shop.ejs
});
app.get('/success', function(req, res) {
    res.render('success.ejs'); //  shop.ejs
});


// PROFILE
app.get('/profile', isLoggedIn, function(req, res) {
res.render('profile.ejs', {
user : req.user
});
});
 // LOGOUT
app.get('/logout', function(req, res) {
req.logout();
res.redirect('/');
});

//login
app.get('/login', function(req, res) {
res.render('login.ejs', { message: req.flash('loginMessage') });
}); //  login
app.post('/login', passport.authenticate('local-login', {
successRedirect : '/',
failureRedirect : '/login',
failureFlash : true
}));

//signup
app.get('/signup', function(req, res) {
res.render('signup.ejs', { message: req.flash('signupMessage') });
});

app.post('/signup', passport.authenticate('local-signup', {
successRedirect : '/', // redirect to the secure profile section
failureRedirect : '/signup', // redirect back to the signup page if there is an error
failureFlash : true // allow flash messages
}));// =============================================================================
// AUTHORIZE (ALREADY LOGGED IN / CONNECTING OTHER SOCIAL ACCOUNT) =============
// ============================================================================= // locally --------------------------------
app.get('/login', function(req, res) {
res.render('signin.ejs', { message: req.flash('loginMessage') });
});
app.post('/login', passport.authenticate('local-signup', {
successRedirect : '/profile', // redirect to the secure profile section
failureRedirect : '/connect/local', // redirect back to the signup page if there is an error
failureFlash : true // allow flash messages
}));// =============================================================================
// UNLINK ACCOUNTS =============================================================
// =============================================================================

app.get('/unlink/local', isLoggedIn, function(req, res) {
var user = req.user;
user.local.email = undefined;
user.local.password = undefined;
user.save(function(err) {
res.redirect('/profile');
});
}); /* add tv show
app.post('/add Show', function(req, res) { var newShow = new show();
newShow.showName = req.body.show;
newShow.save(function (err, newShow) {
if (err) {
res.redirect('/add show');
} else {
res.redirect('add show');
console.log("Document Save Done");
console.log(newShow); }
}); });};
*/
app.post('/checkout', function(req, res) {


      var newcheckout = new checkout();
      newcheckout.fullname = req.body.fullname;
      newcheckout.state = req.body.state;
      newcheckout.email = req.body.email;
      newcheckout.city = req.body.city;
      newcheckout.address = req.body.address;
      newcheckout.phonenumber = req.body.phonenumber;
      newcheckout.cardname = req.body.cardname;
      newcheckout.zip= req.body.zip;
      newcheckout.month= req.body.month;
      newcheckout.year = req.body.year;
      newcheckout.ins= req.body.ins;
      newcheckout.tax= req.body.tax;
      newcheckout.cardNumber = req.body.cardNumber;

       
      newcheckout.save(function(err,newcheckout){
        if(err){
          res.redirect('/event');
            console.log(err);
        }else{
          res.redirect('/success');
            console.log("Document Save Done");
}
  });
});


};

// route middleware to ensure user is logged in
function isLoggedIn(req, res, next) {
if (req.isAuthenticated())
return next(); res.redirect('/');
}

/*// app/routes.js
module.exports = function(app, passport) {

    // =====================================
    // HOME PAGE (with login links) ========
    // =====================================
    app.get('/', function(req, res) {
        res.render('index.ejs'); // load the index.ejs file
    });
    app.get('/checkout', function(req, res) {
        res.render('checkout.ejs'); // load the checkout.ejs file
    });
    app.get('/product-page', function(req, res) {
        res.render('product-page.ejs'); // load the product-page.ejs file
    });
    app.get('/shop', function(req, res) {
        res.render('shop.ejs'); // load the shop.ejs file
    });


    // =====================================
    // LOGIN ===============================
    // =====================================
    // show the login form
    app.get('/login', function(req, res) {

        // render the page and pass in any flash data if it exists
        res.render('login.ejs', { message: req.flash('loginMessage') });
    });

    // process the login form
     app.post('/login', passport.authenticate('local-login', {
         successRedirect : '/', // redirect to the secure profile section
         failureRedirect : '/login', // redirect back to the signup page if there is an error
         failureFlash : true // allow flash messages
     }));


     app.post(' /checkout', passport.authenticate('local-checkout', {
        successRedirect : '/', // redirect to the secure profile section
        failureRedirect : '/checkout', // redirect back to the signup page if there is an error
        failureFlash : true // allow flash messages
    }));

    // =====================================
    // SIGNUP ==============================
    // =====================================
    // show the signup form
    app.get('/signup', function(req, res) {

        // render the page and pass in any flash data if it exists
        res.render('signup.ejs', { message: req.flash('signupMessage') });
    });

    // process the signup form
    app.post('/signup', passport.authenticate('local-signup', {
        successRedirect : '/', // redirect to the secure profile section
        failureRedirect : '/signup', // redirect back to the signup page if there is an error
        failureFlash : true // allow flash messages
    }));

    // =====================================
    // PROFILE SECTION =====================
    // =====================================
    // we will want this protected so you have to be logged in to visit
    // we will use route middleware to verify this (the isLoggedIn function)
    app.get('/profile', isLoggedIn, function(req, res) {
        res.render('profile.ejs', {
            user : req.user // get the user out of session and pass to template
        });
    });

    // =====================================
    // LOGOUT ==============================
    // =====================================
    app.get('/logout', function(req, res) {
        req.logout();
        res.redirect('/');
    });
};

// route middleware to make sure a user is logged in
function isLoggedIn(req, res, next) {

    // if user is authenticated in the session, carry on
    if (req.isAuthenticated())
        return next();

    // if they aren't redirect them to the home page
    res.redirect('/');
}

const express = require("express");
const path = require('path');
const app = express();
app.set("views", path.resolve(__dirname, "views"));
app.set("view engine", "ejs");
*/
