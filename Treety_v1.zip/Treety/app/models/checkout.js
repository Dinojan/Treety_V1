var mongoose = require('mongoose');
//schema to our checkout details
var checkoutSchema = mongoose.Schema({
fullname:{type:String},
state:{type:String},
email:{type:String},
city:{type:String},
address:{type:String},
phonenumber:{type:Number},
cardname: {type:String},
zip:{type:Number},
month:{type:Date},
year: {type:Date},
ins: {type:String},
tax:{type:String},
cardNumber:{type:Number}

});


module.exports = mongoose.model('checkout', checkoutSchema);
